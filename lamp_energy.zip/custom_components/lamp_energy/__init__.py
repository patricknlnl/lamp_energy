"""
Custom Component for Home Assistant: Lamp Energy Sensor
This component calculates the total energy usage of lights based on brightness and wattage.
"""

# This file is intentionally empty as it initializes the custom integration.